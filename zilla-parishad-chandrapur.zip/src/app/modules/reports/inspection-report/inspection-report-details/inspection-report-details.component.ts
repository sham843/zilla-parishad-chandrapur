import { Component } from '@angular/core';

@Component({
  selector: 'app-inspection-report-details',
  templateUrl: './inspection-report-details.component.html',
  styleUrls: ['./inspection-report-details.component.scss']
})
export class InspectionReportDetailsComponent {

}
