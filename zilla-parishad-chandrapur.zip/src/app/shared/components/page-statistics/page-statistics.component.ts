import { Component } from '@angular/core';

@Component({
  selector: 'app-page-statistics',
  templateUrl: './page-statistics.component.html',
  styleUrls: ['./page-statistics.component.scss']
})
export class PageStatisticsComponent {

}
